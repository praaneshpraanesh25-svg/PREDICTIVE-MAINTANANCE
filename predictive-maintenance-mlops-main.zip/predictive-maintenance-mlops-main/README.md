# ⚙️ Predictive Maintenance MLOps Pipeline

An end-to-end, reproducible machine learning pipeline for detecting equipment failures in factory telemetry data. 

Unlike standard static Jupyter Notebook projects, this repository demonstrates **production-grade MLOps practices**. It utilizes a decoupled architecture where Git tracks the codebase, DVC versions the data and pipeline stages, and MLflow handles experiment tracking and model registry.

---

## 📖 The Business Problem
In industrial manufacturing, unexpected machine downtime costs millions of dollars. However, prematurely replacing parts (false positives) is also expensive. 

This project tackles a highly imbalanced classification problem: predicting when a machine will fail based on real-time sensor data (torque, rotational speed, tool wear, and temperature) so maintenance can be scheduled proactively.

### The Dataset
We use the **UCI AI4I 2020 Predictive Maintenance Dataset**, which contains synthetic data points mimicking real-world heavy machinery telemetry.

---

## 🛠️ The Tech Stack & MLOps Tools

* **Data Version Control (DVC):** Used to version raw CSVs and processed Parquet files outside of Git, and to define a deterministic, reproducible execution graph (`dvc.yaml`).
* **MLflow:** Used to track hyperparameter tuning (Random Forest trees, depth, class weights) and compare evaluation metrics (Recall, Precision, ROC-AUC) across different experiment runs.
* **Core Machine Learning:** Python 3.10+, Scikit-Learn, Pandas, PyArrow.

---

## 🏗️ Pipeline Architecture

```text
[Raw Sensor Data (CSV)]
           │
           ▼ (DVC Stage: prepare_data)
[Data Cleaning, Feature Engineering & Parquet Compression]
           │
           ▼ (DVC Stage: train_model)
[Model Training (RandomForest Classifier)]
      ├──▶ Track Metrics, Hyperparameters, & Artifacts (MLflow)
      └──▶ Version Reproducibility & Metadata (DVC Lockfile)
```

### 📂 Repository Structure
```text
├── data/               # Raw and processed datasets (Versioned by DVC)
├── metrics/            # Evaluation metrics (eval.json)
├── mlruns/             # Local MLflow tracking database (Ignored by Git)
├── src/
│   ├── data/           # Preprocessing and feature engineering scripts
│   └── models/         # Training loop and inference scripts
├── dvc.yaml            # DVC pipeline stage definitions
├── dvc.lock            # DVC deterministic pipeline lockfile
├── .gitignore          # Git exclusion rules for artifacts & data
└── README.md
```

---

## 🚀 Quickstart & Reproduction

To reproduce this entire MLOps pipeline on your local machine:

**1. Clone the repository:**
```bash
git clone [https://github.com/KBANDAK/predictive-maintenance-mlops.git](https://github.com/KBANDAK/predictive-maintenance-mlops.git)
cd predictive-maintenance-mlops
```

**2. Set up the virtual environment & dependencies:**
```bash
python -m venv venv
source venv/Scripts/activate  # On Windows: .\venv\Scripts\activate
pip install -r requirements.txt
```

**3. Execute the deterministic pipeline:**
```bash
dvc repro
```

**4. Inspect the experiments:**
```bash
mlflow ui
```
Navigate to `http://127.0.0.1:5000` in your browser.

**5. Test Dynamic Inference:**
```bash
python src/models/predict.py
```
