import pandas as pd
from sklearn.model_selection import train_test_split
import os

def main():
    print("Loading raw data...")
    df = pd.read_csv('data/raw/ai4i2020.csv')
    cols_to_drop = ['UDI', 'Product ID', 'TWF', 'HDF', 'PWF', 'OSF', 'RNF']
    df = df.drop(columns=[c for c in cols_to_drop if c in df.columns])
    type_mapping = {'L': 0, 'M': 1, 'H': 2}
    df['Type'] = df['Type'].map(type_mapping)
    df.columns = df.columns.str.replace(r'[\[\]]', '', regex=True)\
    .str.replace(' ', '_')\
    .str.lower()
    X = df.drop(columns=['machine_failure'])
    y = df['machine_failure']
    print("Splitting data into train/test sets...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    train_df = pd.concat([X_train, y_train], axis=1)
    test_df = pd.concat([X_test, y_test], axis=1)
    os.makedirs('data/processed', exist_ok=True)
    print("Saving processed data as Parquet...")
    train_df.to_parquet('data/processed/train.parquet', index=False)
    test_df.to_parquet('data/processed/test.parquet', index=False)
    print("Done")
if __name__ == '__main__':
    main()