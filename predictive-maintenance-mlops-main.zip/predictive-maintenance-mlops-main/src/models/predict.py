import pandas as pd
import mlflow
import mlflow.sklearn

def predict_single_reading():
    experiment_name = "Predictive_Maintenance_Experimentation"
    print(f"Searching for latest run in experiment: {experiment_name}...")
    df_runs = mlflow.search_runs(experiment_names=[experiment_name])
    
    if df_runs.empty:
        print("No runs found. Make sure you've trained the model first!")
        return
    latest_run_id = df_runs.loc[df_runs['start_time'].idxmax()]['run_id']
    model_uri = f"runs:/{latest_run_id}/model"
    
    print(f"Loading model from run ID: {latest_run_id}...\n")
    model = mlflow.sklearn.load_model(model_uri)
    sample_data = pd.DataFrame([{
        "type": 1,                     # M type machine
        "air_temperature_k": 302.1,    # High ambient temp
        "process_temperature_k": 310.8,
        "rotational_speed_rpm": 1350,  # Low RPM under heavy load
        "torque_nm": 68.5,             # High torque
        "tool_wear_min": 215           # High tool wear
    }])
    
    print("Simulated Telemetry Input:")
    print(sample_data.to_string(index=False))
    prediction = model.predict(sample_data)
    probability = model.predict_proba(sample_data)[0][1]
    
    print("\n--- Prediction Results ---")
    if prediction[0] == 1:
        print(f"WARNING: Machine Failure Predicted! (Confidence: {probability:.2%})")
    else:
        print(f"Machine is operating normally. (Failure Probability: {probability:.2%})")

if __name__ == "__main__":
    predict_single_reading()