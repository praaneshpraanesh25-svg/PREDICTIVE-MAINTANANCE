import os
import json
import pandas as pd
import numpy as np
import mlflow
import mlflow.sklearn

from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix
)

def evaluate_model(y_true, y_pred, y_prob):
    """Calculate key classification metrics for imbalanced sensor data."""
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1_score": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_prob)
    }

def main():
    mlflow.set_experiment("Predictive_Maintenance_Experimentation")
    train_df = pd.read_parquet("data/processed/train.parquet")
    test_df = pd.read_parquet("data/processed/test.parquet")
    X_train = train_df.drop(columns=["machine_failure"])
    y_train = train_df["machine_failure"]
    X_test = test_df.drop(columns=["machine_failure"])
    y_test = test_df["machine_failure"]
    params = {
        "n_estimators": 200,
        "max_depth": 12,
        "class_weight": "balanced_subsample",
        "min_samples_split": 4,
        "random_state": 42
    }
    with mlflow.start_run(run_name="rf_tuned_subsample"):
        mlflow.log_params(params)
        model = RandomForestClassifier(**params)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]
        metrics = evaluate_model(y_test, y_pred, y_prob)
        mlflow.log_metrics(metrics)
        print("Logged Metrics to MLflow:")
        for k, v in metrics.items():
            print(f"  {k}: {v:.4f}")
        os.makedirs("metrics", exist_ok=True)
        with open("metrics/eval.json", "w") as f:
            json.dump(metrics, f, indent=4)
        mlflow.sklearn.log_model(
            sk_model=model,
            artifact_path="model",
            input_example=X_train.head(3)
        )
        print("Model and metadata successfully logged!")

if __name__ == "__main__":
    main()